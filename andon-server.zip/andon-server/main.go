package main

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"sync"

	_ "github.com/mattn/go-sqlite3"
)

type Machine struct {
	Code     string `json:"code"`
	Name     string `json:"name"`
	Location string `json:"location"`
	Operator string `json:"operator"`
}

type AlertRequest struct {
	MachineCode string `json:"machine_code"`
}

type BroadcastRequest struct {
	Message string `json:"message"`
}

var (
	db         *sql.DB
	audioMutex sync.Mutex
)

func initDB() {
	var err error
	os.MkdirAll("./data", os.ModePerm)
	dbPath := filepath.Join("./data", "andon.db")
	
	db, err = sql.Open("sqlite3", dbPath)
	if err != nil {
		log.Fatal("Lỗi mở DB:", err)
	}

	createTableSQL := `
	CREATE TABLE IF NOT EXISTS machines (
		code TEXT PRIMARY KEY,
		name TEXT NOT NULL,
		location TEXT NOT NULL,
		operator TEXT NOT NULL
	);`
	
	_, err = db.Exec(createTableSQL)
	if err != nil {
		log.Fatal("Lỗi tạo bảng:", err)
	}

	// Chèn dữ liệu mẫu cho 10 máy nếu chưa có
	var count int
	db.QueryRow("SELECT COUNT(*) FROM machines").Scan(&count)
	if count == 0 {
		stmt, _ := db.Prepare("INSERT INTO machines(code, name, location, operator) VALUES(?, ?, ?, ?)")
		defer stmt.Close()
		
		initialData := [][]string{
			{"M01", "Máy ép 01", "Xưởng 1 - Dây chuyền A", "Nguyễn Văn A"},
			{"M02", "Máy ép 02", "Xưởng 1 - Dây chuyền A", "Trần Thị B"},
			{"M03", "Máy dập 01", "Xưởng 1 - Dây chuyền B", "Lê Văn C"},
			{"M04", "Máy dập 02", "Xưởng 1 - Dây chuyền B", "Phạm Văn D"},
			{"M05", "Máy phay CNC 01", "Xưởng 2 - Khu CNC", "Hoàng Văn E"},
			{"M06", "Máy phay CNC 02", "Xưởng 2 - Khu CNC", "Vũ Thị F"},
			{"M07", "Máy mài 01", "Xưởng 2 - Khu Gia công", "Đỗ Văn G"},
			{"M08", "Máy mài 02", "Xưởng 2 - Khu Gia công", "Ngô Văn H"},
			{"M09", "Máy đóng gói 01", "Xưởng 3 - Hoàn thiện", "Bùi Thị I"},
			{"M10", "Máy đóng gói 02", "Xưởng 3 - Hoàn thiện", "Trịnh Văn K"},
		}
		for _, row := range initialData {
			stmt.Exec(row[0], row[1], row[2], row[3])
		}
		fmt.Println("Đã khởi tạo 10 máy vào Database!")
	}
}

func downloadTTS(text string, outputFile string) error {
	apiURL := fmt.Sprintf("https://translate.google.com/translate_tts?ie=UTF-8&q=%s&tl=vi&client=tw-ob", url.QueryEscape(text))
	resp, err := http.Get(apiURL)
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	file, err := os.Create(outputFile)
	if err != nil {
		return err
	}
	defer file.Close()

	_, err = io.Copy(file, resp.Body)
	return err
}

func playAudio(filepath string) {
	audioMutex.Lock()
	defer audioMutex.Unlock()
	cmd := exec.Command("mpv", "--no-terminal", filepath)
	_ = cmd.Run()
}

func handleAlert(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	var req AlertRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "Bad request", http.StatusBadRequest)
		return
	}

	var m Machine
	err := db.QueryRow("SELECT code, name, location, operator FROM machines WHERE code = ?", req.MachineCode).
		Scan(&m.Code, &m.Name, &m.Location, &m.Operator)

	if err != nil {
		http.Error(w, "Không tìm thấy máy", http.StatusNotFound)
		return
	}

	alertText := fmt.Sprintf("Cảnh báo! %s tại %s đã dừng. Mời nhân viên %s đến kiểm tra!",
		m.Name, m.Location, m.Operator)

	fmt.Printf("[CẢNH BÁO]: %s\n", alertText)

	go func(msg string) {
		audioFile := "/tmp/alert.mp3"
		if err := downloadTTS(msg, audioFile); err == nil {
			playAudio(audioFile)
		}
	}(alertText)

	w.Header().Set("Content-Type", "application/json")
	w.Write([]byte(`{"status":"success","message":"Đã kích hoạt cảnh báo"}`))
}

func handleBroadcast(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	var req BroadcastRequest
	_ = json.NewDecoder(r.Body).Decode(&req)

	if req.Message == "" {
		http.Error(w, "Nội dung trống", http.StatusBadRequest)
		return
	}

	fmt.Println("[BROADCAST TOÀN XƯỞNG]:", req.Message)

	go func(msg string) {
		audioFile := "/tmp/broadcast.mp3"
		if err := downloadTTS(msg, audioFile); err == nil {
			playAudio(audioFile)
		}
	}(req.Message)

	w.Header().Set("Content-Type", "application/json")
	w.Write([]byte(`{"status":"success","message":"Đã gửi lệnh phát toàn xưởng"}`))
}

func handleMachines(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	
	if r.Method == http.MethodGet {
		rows, err := db.Query("SELECT code, name, location, operator FROM machines")
		if err != nil {
			http.Error(w, err.Error(), 500)
			return
		}
		defer rows.Close()

		var machines []Machine
		for rows.Next() {
			var m Machine
			rows.Scan(&m.Code, &m.Name, &m.Location, &m.Operator)
			machines = append(machines, m)
		}
		json.NewEncoder(w).Encode(machines)
	} else if r.Method == http.MethodPost {
		var m Machine
		_ = json.NewDecoder(r.Body).Decode(&m)
		_, err := db.Exec("INSERT OR REPLACE INTO machines (code, name, location, operator) VALUES (?, ?, ?, ?)",
			m.Code, m.Name, m.Location, m.Operator)
		if err != nil {
			http.Error(w, err.Error(), 500)
			return
		}
		w.Write([]byte(`{"status":"success"}`))
	}
}

func main() {
	initDB()
	defer db.Close()

	// Static Web Files
	fs := http.FileServer(http.Dir("./web"))
	http.Handle("/", fs)

	// API Endpoints
	http.HandleFunc("/api/alert", handleAlert)
	http.HandleFunc("/api/broadcast", handleBroadcast)
	http.HandleFunc("/api/machines", handleMachines)

	fmt.Println("==================================================")
	fmt.Println(" Server Andon đang chạy tại cổng :8080")
	fmt.Println("==================================================")

	log.Fatal(http.ListenAndServe(":8080", nil))
}
