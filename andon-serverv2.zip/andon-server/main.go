package main

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"

	_ "github.com/mattn/go-sqlite3"
)

type Machine struct {
	Code     string `json:"code"`
	Name     string `json:"name"`
	Location string `json:"location"`
	Operator string `json:"operator"`
}

type AlertRequest struct {
	MachineCode string `json:"machine_code"`
}

type ScheduleRequest struct {
	Message     string `json:"message"`
	DateStr     string `json:"date_str"`    // YYYY-MM-DD (Rỗng nếu lặp hàng tuần)
	TimeStr     string `json:"time_str"`    // HH:mm
	RepeatDays  string `json:"repeat_days"` // Ví dụ: "1,2,3,4,5" (1: Thứ 2, ..., 0: CN) hoặc ""
}

type ScheduleItem struct {
	ID          int       `json:"id"`
	Message     string    `json:"message"`
	DateStr     string    `json:"date_str"`
	TimeStr     string    `json:"time_str"`
	RepeatDays  string    `json:"repeat_days"`
	NextRun     time.Time `json:"next_run"`
	Status      string    `json:"status"` // "Pending", "Done"
}

var (
	db          *sql.DB
	speechMutex sync.Mutex
	schedMutex  sync.Mutex
)

func main() {
	var err error
	os.MkdirAll("data", 0755)
	os.MkdirAll("audio_cache", 0755)

	db, err = sql.Open("sqlite3", "./data/andon.db")
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()

	initDB()

	// Khởi chạy Goroutine kiểm tra lịch
	go startScheduler()

	http.HandleFunc("/api/machines", handleMachines)
	http.HandleFunc("/api/alert", handleAlert)
	http.HandleFunc("/api/broadcast", handleBroadcast)
	http.HandleFunc("/api/schedule", handleSchedule)
	http.HandleFunc("/api/schedule/delete", handleDeleteSchedule)

	fs := http.FileServer(http.Dir("./web"))
	http.Handle("/", fs)

	log.Println("Server Andon đang chạy tại cổng :8080...")
	log.Fatal(http.ListenAndServe(":8080", nil))
}

func initDB() {
	// Bảng machines
	db.Exec(`CREATE TABLE IF NOT EXISTS machines (
		code TEXT PRIMARY KEY,
		name TEXT,
		location TEXT,
		operator TEXT
	);`)

	// Bảng schedules
	db.Exec(`CREATE TABLE IF NOT EXISTS schedules (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		message TEXT,
		date_str TEXT,
		time_str TEXT,
		repeat_days TEXT,
		next_run DATETIME,
		status TEXT
	);`)

	var count int
	db.QueryRow("SELECT COUNT(*) FROM machines").Scan(&count)
	if count == 0 {
		for i := 1; i <= 10; i++ {
			code := fmt.Sprintf("M%02d", i)
			name := fmt.Sprintf("Máy ép %02d", i)
			loc := fmt.Sprintf("Xưởng 1 - Dây chuyền %c", 'A'+(i-1)%3)
			op := fmt.Sprintf("Nhân viên %d", i)
			db.Exec("INSERT INTO machines VALUES (?, ?, ?, ?)", code, name, loc, op)
		}
	}
}

func handleMachines(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	if r.Method == "GET" {
		rows, _ := db.Query("SELECT code, name, location, operator FROM machines")
		defer rows.Close()
		var list []Machine
		for rows.Next() {
			var m Machine
			rows.Scan(&m.Code, &m.Name, &m.Location, &m.Operator)
			list = append(list, m)
		}
		json.NewEncoder(w).Encode(list)
	} else if r.Method == "POST" {
		var m Machine
		json.NewDecoder(r.Body).Decode(&m)
		db.Exec("INSERT OR REPLACE INTO machines VALUES (?, ?, ?, ?)", m.Code, m.Name, m.Location, m.Operator)
		json.NewEncoder(w).Encode(map[string]string{"status": "success"})
	}
}

func handleAlert(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		http.Error(w, "Method not allowed", 405)
		return
	}
	var req AlertRequest
	json.NewDecoder(r.Body).Decode(&req)

	var m Machine
	err := db.QueryRow("SELECT code, name, location, operator FROM machines WHERE code = ?", req.MachineCode).
		Scan(&m.Code, &m.Name, &m.Location, &m.Operator)

	if err != nil {
		http.Error(w, "Máy không tồn tại", 404)
		return
	}

	text := fmt.Sprintf("Chú ý! %s tại %s do %s phụ trách đang gặp sự cố và đã dừng hoạt động. Yêu cầu hỗ trợ gấp!", m.Name, m.Location, m.Operator)
	go playTTS(text)

	json.NewEncoder(w).Encode(map[string]string{"status": "alert_triggered", "message": text})
}

func handleBroadcast(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		http.Error(w, "Method not allowed", 405)
		return
	}
	var req struct {
		Message string `json:"message"`
	}
	json.NewDecoder(r.Body).Decode(&req)
	if req.Message != "" {
		go playTTS(req.Message)
	}
	json.NewEncoder(w).Encode(map[string]string{"status": "broadcast_sent"})
}

func handleSchedule(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	if r.Method == "GET" {
		rows, err := db.Query("SELECT id, message, date_str, time_str, repeat_days, next_run, status FROM schedules ORDER BY id DESC")
		if err != nil {
			json.NewEncoder(w).Encode([]ScheduleItem{})
			return
		}
		defer rows.Close()

		var list []ScheduleItem
		for rows.Next() {
			var s ScheduleItem
			rows.Scan(&s.ID, &s.Message, &s.DateStr, &s.TimeStr, &s.RepeatDays, &s.NextRun, &s.Status)
			list = append(list, s)
		}
		json.NewEncoder(w).Encode(list)
	} else if r.Method == "POST" {
		var req ScheduleRequest
		json.NewDecoder(r.Body).Decode(&req)

		nextRun := calculateNextRun(req.DateStr, req.TimeStr, req.RepeatDays)

		schedMutex.Lock()
		_, err := db.Exec("INSERT INTO schedules (message, date_str, time_str, repeat_days, next_run, status) VALUES (?, ?, ?, ?, ?, ?)",
			req.Message, req.DateStr, req.TimeStr, req.RepeatDays, nextRun, "Pending")
		schedMutex.Unlock()

		if err != nil {
			http.Error(w, "Lỗi lưu lịch hẹn", 500)
			return
		}

		json.NewEncoder(w).Encode(map[string]string{"status": "scheduled"})
	}
}

func handleDeleteSchedule(w http.ResponseWriter, r *http.Request) {
	if r.Method != "DELETE" && r.Method != "POST" {
		http.Error(w, "Method not allowed", 405)
		return
	}
	idStr := r.URL.Query().Get("id")
	id, _ := strconv.Atoi(idStr)

	schedMutex.Lock()
	db.Exec("DELETE FROM schedules WHERE id = ?", id)
	schedMutex.Unlock()

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{"status": "deleted"})
}

func calculateNextRun(dateStr, timeStr, repeatDays string) time.Time {
	now := time.Now()
	var hour, min int
	fmt.Sscanf(timeStr, "%d:%d", &hour, &min)

	// Nếu không có lặp (phát 1 lần theo ngày chỉ định)
	if repeatDays == "" {
		if dateStr != "" {
			t, err := time.Parse("2006-01-02", dateStr)
			if err == nil {
				return time.Date(t.Year(), t.Month(), t.Day(), hour, min, 0, 0, now.Location())
			}
		}
		// Nếu không chọn ngày, tính cho hôm nay hoặc ngày mai
		target := time.Date(now.Year(), now.Month(), now.Day(), hour, min, 0, 0, now.Location())
		if now.After(target) {
			target = target.AddDate(0, 0, 1)
		}
		return target
	}

	// Trường hợp lặp lại theo thứ trong tuần
	daysMap := make(map[int]bool)
	for _, d := range strings.Split(repeatDays, ",") {
		val, err := strconv.Atoi(strings.TrimSpace(d))
		if err == nil {
			daysMap[val] = true
		}
	}

	// Tìm ngày tiếp theo khớp với danh sách thứ được chọn
	for i := 0; i < 14; i++ {
		checkDay := now.AddDate(0, 0, i)
		weekday := int(checkDay.Weekday()) // 0: CN, 1: T2, ..., 6: T7
		if daysMap[weekday] {
			target := time.Date(checkDay.Year(), checkDay.Month(), checkDay.Day(), hour, min, 0, 0, now.Location())
			if target.After(now) {
				return target
			}
		}
	}

	return now.Add(1 * time.Hour)
}

func startScheduler() {
	for {
		time.Sleep(2 * time.Second)
		now := time.Now()

		schedMutex.Lock()
		rows, err := db.Query("SELECT id, message, date_str, time_str, repeat_days, next_run, status FROM schedules WHERE status = 'Pending'")
		if err == nil {
			var items []ScheduleItem
			for rows.Next() {
				var s ScheduleItem
				rows.Scan(&s.ID, &s.Message, &s.DateStr, &s.TimeStr, &s.RepeatDays, &s.NextRun, &s.Status)
				items = append(items, s)
			}
			rows.Close()

			for _, s := range items {
				if now.After(s.NextRun) {
					// Phát âm thanh
					go playTTS(s.Message)

					if s.RepeatDays != "" {
						// Tính lại lần chạy tiếp theo nếu lặp lại
						next := calculateNextRun(s.DateStr, s.TimeStr, s.RepeatDays)
						db.Exec("UPDATE schedules SET next_run = ? WHERE id = ?", next, s.ID)
					} else {
						// Đánh dấu đã xong nếu chỉ phát 1 lần
						db.Exec("UPDATE schedules SET status = 'Done' WHERE id = ?", s.ID)
					}
				}
			}
		}
		schedMutex.Unlock()
	}
}

func playTTS(text string) {
	speechMutex.Lock()
	defer speechMutex.Unlock()

	hash := fmt.Sprintf("%x", text)
	cachePath := filepath.Join("audio_cache", hash+".mp3")

	if _, err := os.Stat(cachePath); os.IsNotExist(err) {
		ttsURL := fmt.Sprintf("https://translate.google.com/translate_tts?ie=UTF-8&q=%s&tl=vi&client=tw-ob", url.QueryEscape(text))
		cmd := exec.Command("wget", "-q", "-U", "Mozilla/5.0", ttsURL, "-O", cachePath)
		cmd.Run()
	}

	cmdPlay := exec.Command("mpv", "--no-terminal", cachePath)
	cmdPlay.Run()
}
